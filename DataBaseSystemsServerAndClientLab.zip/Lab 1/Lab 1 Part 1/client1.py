#Ina Patrice Gonzales and Ryan Monaghan
#4 February 2020
#CISC4615
#Lab 1 Part 1 

from socket import *

serverName = 'localhost'
serverPort = 12000
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect((serverName,serverPort)) #makes the connection
sentence = 'Message 1: Hello Fordham'
clientSocket.send(sentence.encode()) #sends 'Hello Fordham'

message = clientSocket.recv(1024) #receives 'Bye' message from server
print ('From Server:', bytes.decode(message)) #prints out 'Bye' from the server

message2 = 'Message 3: Bye'
clientSocket.send(message2.encode()) #sends out 'Bye' from client

print ('Connection Closed') #outputs that the connection is closed 
clientSocket.close()
