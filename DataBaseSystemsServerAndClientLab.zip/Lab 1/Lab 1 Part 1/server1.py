#Ina Patrice Gonzales and Ryan Monaghan
#4 February 2020
#CISC4615
#Lab 1 Part 1 

from socket import *

serverPort = 12000
serverSocket = socket(AF_INET,SOCK_STREAM)
serverSocket.bind(('localhost',serverPort))
serverSocket.listen(1)
print ('The server is ready to receive')
while 1:
	connectionSocket, addr = serverSocket.accept()
	sentence = connectionSocket.recv(1024) #receives 'Hello Fordham' from Client
	print('From Client:', bytes.decode(sentence)) #prints out 'Hello Fordham' 
	message = 'Message 2: Bye'
	connectionSocket.send(message.encode()) #sends out 'Bye' from server
	message2 = connectionSocket.recv(1024)  #receives 'Bye' from client
	print ('From Client:', bytes.decode(message2)) #prints out 'Bye' from client
	break
print ('Connection Closed')
connectionSocket.close()
